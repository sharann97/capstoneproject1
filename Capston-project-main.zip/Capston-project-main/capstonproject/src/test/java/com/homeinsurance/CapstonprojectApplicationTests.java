package com.homeinsurance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstonprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
